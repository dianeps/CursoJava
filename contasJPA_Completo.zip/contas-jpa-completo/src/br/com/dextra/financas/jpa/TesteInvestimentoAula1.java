package br.com.dextra.financas.jpa;

import br.com.dextra.financas.modelo.InvestimentoAula1;;


public class TesteInvestimentoAula1 {
	
	// Criado novo investimento
	InvestimentoAula1 di = new InvestimentoAula1();
	
	
	
	


}
