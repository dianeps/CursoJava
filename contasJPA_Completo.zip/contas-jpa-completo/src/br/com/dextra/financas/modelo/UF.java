package br.com.dextra.financas.modelo;

public enum UF {
	SP, MG, SC, RJ, DF, RN;
}
