package br.com.dextra.financas.modelo;

public enum TipoContato {
	TELEFONE, EMAIL, CX_POSTAL, SKYPE;
}
