package br.com.dextra.testesrelacionamentos;

public enum UF {
	SP, MG, SC, RJ, DF, RN;
}
